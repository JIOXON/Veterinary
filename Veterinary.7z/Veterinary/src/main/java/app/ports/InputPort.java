package app.ports;

public interface InputPort {
	public void menu() throws Exception;	
}